package net.rmj.earthquakebot;

import android.app.Activity;
import android.os.Bundle;

public class EarthquakeBotMessages extends Activity {
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.messages);
		
	}

}
